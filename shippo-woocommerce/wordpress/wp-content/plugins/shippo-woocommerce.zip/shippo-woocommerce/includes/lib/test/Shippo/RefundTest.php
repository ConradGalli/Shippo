<?php

// Intentionally left blank
class Shippo_RefundTest extends UnitTestCase
{
    public function testTrue()
    {
        $this->assertEqual("equal", "equal");
    }
    
}
