<?php

class Shippo_AuthenticationError extends Shippo_Error
{
}
